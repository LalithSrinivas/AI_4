#! /bin/bash
g++ startup_code.cpp -std=c++11 -o main