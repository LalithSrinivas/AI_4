#! /bin/bash
./main $1 $2
